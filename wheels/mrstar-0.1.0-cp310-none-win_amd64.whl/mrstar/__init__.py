from .mrstar import *

__doc__ = mrstar.__doc__
if hasattr(mrstar, "__all__"):
    __all__ = mrstar.__all__